# Traffic Handler Docker

## BETA Version. Bitte aktuell nur zu Testzwecken nutzen. Nicht Produktiv schalten.

## Informationen
Es handelt sich hier um das Konfigurationspaket für eine Docker-Installation.

Bitte lesen Sie sich vor Inbetriebnahem die Dokumentation aufmerksam durch.

[Dokumentation](https://doc.err-fire.de/docs)